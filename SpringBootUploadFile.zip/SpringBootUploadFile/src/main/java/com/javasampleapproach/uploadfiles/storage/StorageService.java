package com.javasampleapproach.uploadfiles.storage;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

import com.javasampleapproach.uploadfiles.dao.IImageUploadDao;
import com.javasampleapproach.uploadfiles.model.ProductImage;

@Service("storageService")
public class StorageService {
   @Autowired
   IImageUploadDao uploadDao;
   
	Logger log = LoggerFactory.getLogger(this.getClass().getName());
	private final Path rootLocation = Paths.get("D:\\Users\\ashukl10\\Downloads\\SpringBootUploadFile\\src\\main\\resources\\static\\upload-dir");
	ProductImage productImage=new ProductImage();
	public void store(MultipartFile file,String productId) {
		
		try {
			productId=productId+".jpg";
			Files.copy(file.getInputStream(), this.rootLocation.resolve(file.getOriginalFilename().replace(file.getOriginalFilename(), productId)));
			
			dbStore(this.rootLocation.resolve(file.getOriginalFilename().replace(file.getOriginalFilename(), productId)).toString());
		} catch (Exception e) {
			throw new RuntimeException("FAIL!");
		}
	}
	
	public void dbStore(String string) {
		productImage.setImageUrl(string);
		productImage.setImageStatus("main");
		
		uploadDao.save(productImage);
	}

	public Resource loadFile(String filename) {
		try {
			Path file = rootLocation.resolve(filename);
			Resource resource = new UrlResource(file.toUri());
			if (resource.exists() || resource.isReadable()) {
				return resource;
			} else {
				throw new RuntimeException("FAIL!");
			}
		} catch (MalformedURLException e) {
			throw new RuntimeException("FAIL!");
		}
	}

	/*public void deleteAll() {
		//FileSystemUtils.copyRecursively(rootLocation.toFile(),Paths.get("D:\\Users\\ashukl10\\Downloads\\SpringBootUploadFile\\src\\main\\resources\\static\\upload-dir"));
		
		FileSystemUtils.deleteRecursively(rootLocation.toFile());
	}*/

	public void init() {
		try {
			if(!Files.isDirectory(rootLocation))
			    Files.createDirectories(rootLocation);
		} catch (IOException e) {
			throw new RuntimeException("Could not initialize storage!");
		}
	}

}
